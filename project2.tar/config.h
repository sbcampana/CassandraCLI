#ifndef __CONFIG_H
#define __CONFIG_H


#define BUFSIZE		(1 << 12)


#endif
